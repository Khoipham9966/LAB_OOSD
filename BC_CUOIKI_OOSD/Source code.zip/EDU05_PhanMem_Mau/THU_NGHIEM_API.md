# Thử API bằng curl (sau khi Spring Boot chạy)

Mở PowerShell. Những lệnh dưới đây dùng tài khoản giả lập **chỉ trên localhost**:

```powershell
# Xem thông tin người đang đăng nhập
curl.exe -u covan:Demo@123 http://localhost:8080/api/me

# Xem danh sách học sinh phụ trách
curl.exe -u covan:Demo@123 http://localhost:8080/api/students

# Xem cảnh báo trước và sau khi sinh
curl.exe -u covan:Demo@123 http://localhost:8080/api/alerts

# Chạy sinh cảnh báo thủ công để demo
curl.exe -u covan:Demo@123 -X POST http://localhost:8080/api/alerts/generate

# Xem cảnh báo lại (id ví dụ là 1)
curl.exe -u covan:Demo@123 http://localhost:8080/api/alerts

# Duyệt cảnh báo mã 1
curl.exe -u covan:Demo@123 -X PATCH http://localhost:8080/api/alerts/1/review -H 'Content-Type: application/json' -d '{"duyet":true}'

# Sinh viên phản hồi
curl.exe -u sinhvien1:Demo@123 -X POST http://localhost:8080/api/alerts/1/feedback -H 'Content-Type: application/json' -d '{"noiDung":"Em cần cố vấn hướng dẫn cách ôn tập."}'

# Cố vấn hoàn tất
curl.exe -u covan:Demo@123 -X PATCH http://localhost:8080/api/alerts/1/resolve -H 'Content-Type: application/json' -d '{"ketLuan":"Đã trao đổi và thống nhất hướng ôn tập."}'
```

**Chú ý:** Trong PowerShell, đôi khi cách escape JSON khi truyền qua `curl.exe` khác Terminal Bash. Nếu lệnh có JSON lỗi, hãy dùng **Postman** (Authorization → Basic Auth; Body → raw → JSON) hoặc thử bằng giao diện Web tại `http://localhost:5173`. Không chạy lệnh thay đổi trạng thái nhiều lần cho cùng bản ghi; hệ thống có kiểm tra trạng thái hợp lệ.
