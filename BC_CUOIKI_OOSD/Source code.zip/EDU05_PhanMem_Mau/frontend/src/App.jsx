import { useEffect, useState } from 'react';
import { api, saveLogin, forgetLogin, getLogin } from './api.js';

// =======================================================================
// CHO DE THAY SUA TRONG LUC DEMO:
// - Doi ten cot / dong chu: sua JSX ben duoi, luu Ctrl+S, Web tu cap nhat.
// - Doi mau: sua style.css (cac bien --blue, --green ...).
// - Doi nguong canh bao: vao tai khoan admin -> Quy tac, hoac pgAdmin.
// =======================================================================

const states = {
  NHAP: 'Nháp', DA_GUI: 'Đã gửi', DA_PHAN_HOI: 'Đã phản hồi',
  DA_XU_LY: 'Đã xử lý', BI_TU_CHOI: 'Bị từ chối',
};
const roles = { CO_VAN: 'Cố vấn', HOC_VIEN: 'Người học', QUAN_TRI: 'Quản trị viên' };

function Panel({ title, children }) {
  return <section className="panel"><h2>{title}</h2>{children}</section>;
}
function Button({ children, onClick, color = 'blue', disabled = false }) {
  return <button type="button" className={'btn ' + color} onClick={onClick} disabled={disabled}>{children}</button>;
}
function Message({ error, notice }) {
  return <>{error && <div className="error">{error}</div>}{notice && <div className="success">{notice}</div>}</>;
}

function Login({ onLogin }) {
  const [username, setUsername] = useState('covan');
  const [password, setPassword] = useState('Demo@123');
  const [error, setError] = useState('');
  async function submit(event) {
    event.preventDefault(); setError('');
    saveLogin(username.trim(), password);
    try { onLogin(await api('/me')); }
    catch { forgetLogin(); setError('Sai tài khoản, mật khẩu hoặc backend chưa chạy'); }
  }
  return <div className="login-frame">
    <div className="login-card">
      <header className="header">HỆ THỐNG CỐ VẤN HỌC TẬP</header>
      <h2>ĐĂNG NHẬP HỆ THỐNG</h2>
      <form onSubmit={submit}>
        <label>Tài khoản</label>
        <input value={username} onChange={e => setUsername(e.target.value)} placeholder="covan" required />
        <label>Mật khẩu</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
        <button className="btn green wide">ĐĂNG NHẬP</button>
        {error && <div className="error">{error}</div>}
      </form>
      <small>Demo: <b>admin</b>, <b>covan</b>, <b>sinhvien1</b>, <b>sinhvien2</b> — Mật khẩu: <b>Demo@123</b></small>
    </div>
  </div>;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [profile, setProfile] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [plans, setPlans] = useState([]);
  const [users, setUsers] = useState([]);
  const [rules, setRules] = useState([]);
  const [feedbackText, setFeedbackText] = useState({});
  const [planTarget, setPlanTarget] = useState(null);
  const [planForm, setPlanForm] = useState({ mucTieu: 'Cải thiện kết quả môn học', bienPhap: 'Ôn tập theo kế hoạch và gặp cố vấn', batDau: '2026-11-10', hanHoanThanh: '2026-12-10' });
  const [newUser, setNewUser] = useState({tenDangNhap: '', hoTen: '', vaiTro: 'HOC_VIEN', matKhau: 'Demo@123'});
  const [newRule, setNewRule] = useState({ten: 'Điểm tổng hợp dưới 6', toanTu: '<', nguong: '6'});

  useEffect(() => { if (getLogin()) api('/me').then(selectUser).catch(forgetLogin); }, []);
  function selectUser(account) {
    setUser(account);
    setPage(account.vai_tro === 'CO_VAN' ? 'students' : account.vai_tro === 'HOC_VIEN' ? 'profile' : 'users');
  }
  function logout() { forgetLogin(); setUser(null); setPage(''); setError(''); setNotice(''); }
  function run(action) {
    setError(''); setNotice('');
    Promise.resolve().then(action).then(value => {
      setNotice(typeof value === 'string' ? value : 'Thao tác thành công');
      reload();
    }).catch(err => setError(err.message));
  }
  function reload() {
    if (!user) return;
    if (page === 'students') api('/students').then(setStudents).catch(e => setError(e.message));
    if (page === 'alerts') api('/alerts').then(setAlerts).catch(e => setError(e.message));
    if (page === 'plans') api('/plans').then(setPlans).catch(e => setError(e.message));
    if (page === 'users') api('/admin/users').then(setUsers).catch(e => setError(e.message));
    if (page === 'rules') api('/admin/rules').then(setRules).catch(e => setError(e.message));
    if (page === 'profile') {
      const id = user.vai_tro === 'HOC_VIEN' ? user.id : selectedStudent;
      if (id) api('/profiles/' + id).then(setProfile).catch(e => setError(e.message));
    }
  }
  useEffect(() => { reload(); }, [page, user, selectedStudent]);
  if (!user) return <Login onLogin={selectUser} />;

  const advisor = user.vai_tro === 'CO_VAN';
  const student = user.vai_tro === 'HOC_VIEN';
  const admin = user.vai_tro === 'QUAN_TRI';
  const tabs = advisor ? [ ['students', 'Người học'], ['alerts', 'Cảnh báo'], ['plans', 'Kế hoạch can thiệp'], ['password', 'Đổi mật khẩu'] ]
     : student ? [ ['profile', 'Hồ sơ năng lực'], ['alerts', 'Cảnh báo của tôi'], ['password', 'Đổi mật khẩu'] ]
     : [ ['users', 'Quản lý tài khoản'], ['rules', 'Quy tắc cảnh báo'], ['password', 'Đổi mật khẩu'] ];

  return <>
    <header className="header">
      <div><strong>EDU-05</strong> | HỆ THỐNG CỐ VẤN HỌC TẬP</div>
      <div>{user.ho_ten} — {roles[user.vai_tro]} <Button color="gray" onClick={logout}>Đăng xuất</Button></div>
    </header>
    <nav>{tabs.map(([key, name]) => <button key={key} className={page === key ? 'active' : ''} onClick={() => { setPage(key); setNotice(''); setError(''); }}>{name}</button>)}</nav>
    <main>
      <Message error={error} notice={notice} />
      {page === 'students' && advisor && <Panel title="DANH SÁCH NGƯỜI HỌC">
        <div className="actions"><Button onClick={reload}>Làm mới dữ liệu</Button></div>
        <table><thead><tr><th>Mã</th><th>Họ và tên</th><th>Lớp</th><th>Điểm tổng hợp</th><th>Số cảnh báo</th><th>Thao tác</th></tr></thead>
          <tbody>{students.map(s => <tr key={s.id}><td>{s.id}</td><td>{s.ho_ten}</td><td>{s.ten_lop}</td><td>{s.diem_tong_hop ?? 'Chưa có'}</td><td>{s.so_canh_bao}</td><td><Button onClick={() => { setSelectedStudent(s.id); setPage('profile'); }}>Xem hồ sơ</Button></td></tr>)}</tbody></table>
      </Panel>}
      {page === 'profile' && <Panel title="HỒ SƠ NĂNG LỰC NGƯỜI HỌC">
        {!profile ? <p>Đang tải hồ sơ...</p> : <>
          <div className="summary"><b>Họ tên:</b> {profile.hoSo.ho_ten} &nbsp; | &nbsp; <b>Lớp:</b> {profile.hoSo.ten_lop} &nbsp; | &nbsp; <b>Điểm tổng hợp:</b> {profile.hoSo.diem_tong_hop ?? 'Chưa có'}</div>
          <p><b>Đánh giá:</b> {profile.hoSo.danh_gia}</p>
          <table><thead><tr><th>Môn học</th><th>Loại đánh giá</th><th>Điểm số</th><th>Ngày đánh giá</th></tr></thead>
          <tbody>{profile.ketQua.map((k, i) => <tr key={i}><td>{k.mon_hoc}</td><td>{k.loai_danh_gia}</td><td>{k.diem}</td><td>{k.ngay_danh_gia}</td></tr>)}</tbody></table>
        </>}
      </Panel>}
      {page === 'alerts' && <Panel title={advisor ? 'XEM XÉT CẢNH BÁO' : 'CẢNH BÁO CỦA TÔI'}>
        <div className="actions">{advisor && <Button color="green" onClick={() => run(async () => { const r = await api('/alerts/generate', 'POST'); return `Đã tạo ${r.soCanhBaoMoi} cảnh báo mới`; })}>Chạy kiểm tra cảnh báo (demo)</Button>} <Button onClick={reload}>Làm mới</Button></div>
        {!alerts.length && <p>Chưa có cảnh báo nào. Cố vấn hãy bấm “Chạy kiểm tra cảnh báo (demo)”.</p>}
        {alerts.map(a => <div className="alert-card" key={a.id}>
          <div><b>Cảnh báo #{a.id}</b> — {advisor ? a.nguoi_hoc : 'Hồ sơ của bạn'} <span className={'state ' + a.trang_thai}>{states[a.trang_thai]}</span></div>
          <p><b>Quy tắc:</b> {a.ten_quy_tac} &nbsp; | &nbsp; <b>Giá trị thực tế:</b> {a.gia_tri_thuc_te} &nbsp; | &nbsp; <b>Ngưỡng:</b> {a.nguong_ap_dung}</p>
          <p><b>Lý do:</b> {a.ly_do}</p>
          {advisor && a.phan_hoi_moi_nhat && <p className="summary"><b>Phản hồi người học:</b> {a.phan_hoi_moi_nhat}</p>}
          {advisor && a.trang_thai === 'NHAP' && <div className="actions">
            <Button color="green" onClick={() => run(() => api(`/alerts/${a.id}/review`, 'PATCH', {duyet:true}))}>Duyệt</Button>
            <Button color="red" onClick={() => { const reason = prompt('Nhập lý do từ chối:'); if (reason) run(() => api(`/alerts/${a.id}/review`, 'PATCH', {duyet:false,lyDo:reason})); }}>Từ chối</Button>
          </div>}
          {advisor && ['DA_GUI','DA_PHAN_HOI','DA_XU_LY'].includes(a.trang_thai) && <div className="actions">
            <Button onClick={() => { setPlanTarget(a.id); setPage('plans'); }}>Lập kế hoạch</Button>
            {a.trang_thai === 'DA_PHAN_HOI' && <Button color="green" onClick={() => { const note = prompt('Kết luận xử lý:'); if (note) run(() => api(`/alerts/${a.id}/resolve`,'PATCH',{ketLuan:note})); }}>Đánh dấu Đã xử lý</Button>}
          </div>}
          {student && a.trang_thai === 'DA_GUI' && <div className="response-form">
            <label>Nội dung phản hồi</label>
            <textarea placeholder="Nhập lý do giải trình..." value={feedbackText[a.id] || ''} onChange={e => setFeedbackText({...feedbackText,[a.id]:e.target.value})} />
            <Button color="green" onClick={() => run(() => api(`/alerts/${a.id}/feedback`,'POST',{noiDung:feedbackText[a.id] || ''}))}>Gửi phản hồi</Button>
          </div>}
        </div>)}
      </Panel>}
      {page === 'plans' && advisor && <>
        <Panel title="LẬP KẾ HOẠCH CAN THIỆP">
          <p>Chọn cảnh báo từ tab Cảnh báo, sau đó nhập thông tin dưới đây.</p>
          <label>Mã cảnh báo</label><input type="number" value={planTarget ?? ''} onChange={e => setPlanTarget(e.target.value)} placeholder="VD: 1" />
          <label>Mục tiêu</label><input value={planForm.mucTieu} onChange={e => setPlanForm({...planForm,mucTieu:e.target.value})} />
          <label>Biện pháp</label><textarea value={planForm.bienPhap} onChange={e => setPlanForm({...planForm,bienPhap:e.target.value})} />
          <div className="form-row"><div><label>Ngày bắt đầu</label><input type="date" value={planForm.batDau} onChange={e => setPlanForm({...planForm,batDau:e.target.value})} /></div>
          <div><label>Hạn hoàn thành</label><input type="date" value={planForm.hanHoanThanh} onChange={e => setPlanForm({...planForm,hanHoanThanh:e.target.value})} /></div></div>
          <Button color="green" onClick={() => run(() => api(`/alerts/${planTarget}/plans`,'POST',planForm))}>Lưu kế hoạch</Button>
        </Panel>
        <Panel title="DANH SÁCH KẾ HOẠCH">
          <table><thead><tr><th>Mã</th><th>Cảnh báo</th><th>Người học</th><th>Mục tiêu</th><th>Hạn</th><th>Trạng thái</th></tr></thead>
            <tbody>{plans.map(p => <tr key={p.id}><td>{p.id}</td><td>{p.canh_bao_id}</td><td>{p.nguoi_hoc}</td><td>{p.muc_tieu}</td><td>{p.han_hoan_thanh}</td><td>{p.trang_thai}</td></tr>)}</tbody></table>
        </Panel>
      </>}
      {page === 'users' && admin && <>
        <Panel title="QUẢN LÝ TÀI KHOẢN">
          <table><thead><tr><th>ID</th><th>Tài khoản</th><th>Họ và tên</th><th>Vai trò</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
            <tbody>{users.map(u => <tr key={u.id}><td>{u.id}</td><td>{u.ten_dang_nhap}</td><td>{u.ho_ten}</td><td>{roles[u.vai_tro]}</td><td>{u.trang_thai}</td><td><Button color="gray" onClick={() => run(() => api(`/admin/users/${u.id}/status`,'PATCH',{trangThai:u.trang_thai==='HOAT_DONG'?'KHOA':'HOAT_DONG'}))}>Khóa/Mở khóa</Button></td></tr>)}</tbody></table>
        </Panel>
        <Panel title="THÊM TÀI KHOẢN (DEMO)">
          <label>Tên đăng nhập</label><input value={newUser.tenDangNhap} onChange={e => setNewUser({...newUser,tenDangNhap:e.target.value})}/>
          <label>Họ tên</label><input value={newUser.hoTen} onChange={e => setNewUser({...newUser,hoTen:e.target.value})}/>
          <label>Vai trò</label><select value={newUser.vaiTro} onChange={e => setNewUser({...newUser,vaiTro:e.target.value})}><option value="HOC_VIEN">Người học</option><option value="CO_VAN">Cố vấn</option><option value="QUAN_TRI">Quản trị viên</option></select>
          <label>Mật khẩu mẫu</label><input value={newUser.matKhau} onChange={e => setNewUser({...newUser,matKhau:e.target.value})}/>
          <Button color="green" onClick={() => run(() => api('/admin/users','POST',newUser))}>Tạo tài khoản</Button>
        </Panel>
      </>}
      {page === 'rules' && admin && <>
        <Panel title="QUY TẮC CẢNH BÁO HỌC TẬP">
          <table><thead><tr><th>ID</th><th>Tên quy tắc</th><th>Chỉ số</th><th>Điều kiện</th><th>Trạng thái</th></tr></thead>
          <tbody>{rules.map(r => <tr key={r.id}><td>{r.id}</td><td>{r.ten}</td><td>{r.loai_chi_so}</td><td>{r.toan_tu} {r.nguong}</td><td>{r.hoat_dong ? 'Hoạt động' : 'Tắt'}</td></tr>)}</tbody></table>
          <label>Tên quy tắc mới</label><input value={newRule.ten} onChange={e => setNewRule({...newRule,ten:e.target.value})}/>
          <div className="form-row"><div><label>Toán tử</label><select value={newRule.toanTu} onChange={e => setNewRule({...newRule,toanTu:e.target.value})}><option value="<">Nhỏ hơn (&lt;)</option><option value="<=">Nhỏ hơn hoặc bằng</option><option value=">">Lớn hơn (&gt;)</option><option value=">=">Lớn hơn hoặc bằng</option></select></div><div><label>Ngưỡng (0-10)</label><input type="number" step="0.1" min="0" max="10" value={newRule.nguong} onChange={e => setNewRule({...newRule,nguong:e.target.value})}/></div></div>
          <Button color="green" onClick={() => run(() => api('/admin/rules','POST',newRule))}>Thêm quy tắc</Button>
        </Panel>
      </>}
      {page === 'password' && <PasswordForm onChanged={logout} />}
    </main>
    <footer>EDU-05 — Bản demo nội bộ | Hồ sơ năng lực & kết quả học tập | Không sử dụng chuyên cần</footer>
  </>;
}

function PasswordForm({ onChanged }) {
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [error, setError] = useState('');
  return <Panel title="ĐỔI MẬT KHẨU">
    <label>Mật khẩu hiện tại</label><input type="password" value={oldPass} onChange={e=>setOldPass(e.target.value)}/>
    <label>Mật khẩu mới</label><input type="password" value={newPass} onChange={e=>setNewPass(e.target.value)}/>
    <Button color="green" onClick={async () => { try { await api('/password','PUT',{matKhauCu:oldPass,matKhauMoi:newPass}); alert('Đổi mật khẩu thành công. Vui lòng đăng nhập lại.'); onChanged(); } catch(e) { setError(e.message); } }}>Lưu mật khẩu</Button>
    {error && <div className="error">{error}</div>}
  </Panel>;
}
