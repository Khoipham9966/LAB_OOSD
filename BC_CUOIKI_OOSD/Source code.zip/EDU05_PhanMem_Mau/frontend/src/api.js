// Doi API chi can sua file nay. Ban demo localhost dung HTTP Basic.
const KEY = 'edu05-demo-account';

export function saveLogin(username, password) {
  sessionStorage.setItem(KEY, JSON.stringify({ username, password }));
}
export function forgetLogin() { sessionStorage.removeItem(KEY); }
export function getLogin() { return JSON.parse(sessionStorage.getItem(KEY) || 'null'); }

export async function api(path, method = 'GET', body = undefined) {
  const login = getLogin();
  if (!login) throw new Error('Bạn chưa đăng nhập');
  const result = await fetch('/api' + path, {
    method,
    headers: {
      'Authorization': 'Basic ' + btoa(`${login.username}:${login.password}`),
      ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  if (!result.ok) {
    let message = `HTTP ${result.status}`;
    try {
      const data = await result.json();
      message = data.detail || data.message || data.error || message;
    } catch { /* response khong phai JSON */ }
    throw new Error(message);
  }
  return result.json();
}
