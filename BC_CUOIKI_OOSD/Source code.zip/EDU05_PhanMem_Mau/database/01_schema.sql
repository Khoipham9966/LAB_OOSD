-- EDU-05 / PostgreSQL. Chay trong CSDL edu05 bang pgAdmin Query Tool.
-- Khong co bang va truong chuyen can.
CREATE TABLE IF NOT EXISTS nguoi_dung (
 id BIGSERIAL PRIMARY KEY,
 ten_dang_nhap VARCHAR(50) UNIQUE NOT NULL,
 mat_khau_hash TEXT NOT NULL,
 ho_ten VARCHAR(150) NOT NULL,
 vai_tro VARCHAR(20) NOT NULL CHECK (vai_tro IN ('HOC_VIEN','CO_VAN','QUAN_TRI')),
 trang_thai VARCHAR(20) NOT NULL DEFAULT 'HOAT_DONG' CHECK (trang_thai IN ('HOAT_DONG','KHOA'))
);
CREATE TABLE IF NOT EXISTS lop_hoc (
 id BIGSERIAL PRIMARY KEY,
 ma_lop VARCHAR(50) UNIQUE NOT NULL,
 ten_lop VARCHAR(150) NOT NULL
);
CREATE TABLE IF NOT EXISTS co_van (
 nguoi_dung_id BIGINT PRIMARY KEY REFERENCES nguoi_dung(id)
);
CREATE TABLE IF NOT EXISTS nguoi_hoc (
 nguoi_dung_id BIGINT PRIMARY KEY REFERENCES nguoi_dung(id),
 lop_hoc_id BIGINT NOT NULL REFERENCES lop_hoc(id),
 co_van_id BIGINT NOT NULL REFERENCES co_van(nguoi_dung_id)
);
CREATE TABLE IF NOT EXISTS ho_so_nang_luc (
 id BIGSERIAL PRIMARY KEY,
 nguoi_hoc_id BIGINT UNIQUE NOT NULL REFERENCES nguoi_hoc(nguoi_dung_id),
 diem_tong_hop NUMERIC(4,2),
 danh_gia TEXT,
 cap_nhat_luc TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ket_qua_hoc_tap (
 id BIGSERIAL PRIMARY KEY,
 ho_so_id BIGINT NOT NULL REFERENCES ho_so_nang_luc(id),
 mon_hoc VARCHAR(150) NOT NULL,
 loai_danh_gia VARCHAR(100) NOT NULL,
 diem NUMERIC(4,2) NOT NULL CHECK (diem BETWEEN 0 AND 10),
 ngay_danh_gia DATE NOT NULL
);
CREATE TABLE IF NOT EXISTS quy_tac_canh_bao (
 id BIGSERIAL PRIMARY KEY,
 ten VARCHAR(150) NOT NULL,
 loai_chi_so VARCHAR(40) NOT NULL DEFAULT 'DIEM_TONG_HOP',
 toan_tu VARCHAR(4) NOT NULL DEFAULT '<' CHECK (toan_tu IN ('<','<=','>','>=')),
 nguong NUMERIC(4,2) NOT NULL,
 phien_ban INT NOT NULL DEFAULT 1,
 hoat_dong BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS canh_bao (
 id BIGSERIAL PRIMARY KEY,
 nguoi_hoc_id BIGINT NOT NULL REFERENCES nguoi_hoc(nguoi_dung_id),
 quy_tac_id BIGINT NOT NULL REFERENCES quy_tac_canh_bao(id),
 gia_tri_thuc_te NUMERIC(4,2) NOT NULL,
 nguong_ap_dung NUMERIC(4,2) NOT NULL,
 ly_do TEXT NOT NULL,
 trang_thai VARCHAR(20) NOT NULL DEFAULT 'NHAP' CHECK (trang_thai IN ('NHAP','DA_GUI','DA_PHAN_HOI','DA_XU_LY','BI_TU_CHOI')),
 nguoi_duyet_id BIGINT REFERENCES co_van(nguoi_dung_id),
 ly_do_tu_choi TEXT,
 tao_luc TIMESTAMP NOT NULL DEFAULT NOW(),
 gui_luc TIMESTAMP
);
CREATE TABLE IF NOT EXISTS phan_hoi (
 id BIGSERIAL PRIMARY KEY,
 canh_bao_id BIGINT NOT NULL REFERENCES canh_bao(id),
 nguoi_hoc_id BIGINT NOT NULL REFERENCES nguoi_hoc(nguoi_dung_id),
 noi_dung TEXT NOT NULL,
 tao_luc TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ke_hoach_can_thiep (
 id BIGSERIAL PRIMARY KEY,
 canh_bao_id BIGINT NOT NULL UNIQUE REFERENCES canh_bao(id),
 co_van_id BIGINT NOT NULL REFERENCES co_van(nguoi_dung_id),
 muc_tieu TEXT NOT NULL,
 bien_phap TEXT NOT NULL,
 bat_dau DATE NOT NULL,
 han_hoan_thanh DATE NOT NULL,
 trang_thai VARCHAR(20) NOT NULL DEFAULT 'MOI_LAP',
 ket_qua TEXT,
 CONSTRAINT han_hop_le CHECK (han_hoan_thanh >= bat_dau)
);
CREATE TABLE IF NOT EXISTS lich_su_canh_bao (
 id BIGSERIAL PRIMARY KEY,
 canh_bao_id BIGINT NOT NULL REFERENCES canh_bao(id),
 tu_trang_thai VARCHAR(20),
 den_trang_thai VARCHAR(20) NOT NULL,
 nguoi_thuc_hien_id BIGINT REFERENCES nguoi_dung(id),
 ghi_chu TEXT,
 thoi_diem TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS thong_bao (
 id BIGSERIAL PRIMARY KEY,
 nguoi_nhan_id BIGINT NOT NULL REFERENCES nguoi_dung(id),
 canh_bao_id BIGINT REFERENCES canh_bao(id),
 noi_dung TEXT NOT NULL,
 da_doc BOOLEAN NOT NULL DEFAULT FALSE,
 tao_luc TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_canh_bao_sv ON canh_bao(nguoi_hoc_id);
CREATE INDEX IF NOT EXISTS idx_canh_bao_status ON canh_bao(trang_thai);
CREATE INDEX IF NOT EXISTS idx_phan_hoi_canh_bao ON phan_hoi(canh_bao_id);
