-- Du lieu mau de demo localhost. Mat khau chung: Demo@123
-- Chi su dung thong tin gia lap, khong dua mat khau thuong vao database.
INSERT INTO nguoi_dung (id,ten_dang_nhap,mat_khau_hash,ho_ten,vai_tro) VALUES
 (1,'admin','$2a$10$FjZkCggptHS1TG/daf51r.XYGDcvk0Ru1ixA0BY44UhMnv7e67eH.','Quản trị viên mẫu','QUAN_TRI'),
 (2,'covan','$2a$10$FjZkCggptHS1TG/daf51r.XYGDcvk0Ru1ixA0BY44UhMnv7e67eH.','Cố vấn Nguyễn Minh','CO_VAN'),
 (3,'sinhvien1','$2a$10$FjZkCggptHS1TG/daf51r.XYGDcvk0Ru1ixA0BY44UhMnv7e67eH.','Người học Trần An','HOC_VIEN'),
 (4,'sinhvien2','$2a$10$FjZkCggptHS1TG/daf51r.XYGDcvk0Ru1ixA0BY44UhMnv7e67eH.','Người học Lê Bình','HOC_VIEN')
ON CONFLICT (id) DO NOTHING;
INSERT INTO lop_hoc(id,ma_lop,ten_lop) VALUES (1,'CNTT-01','Lớp CNTT 01') ON CONFLICT DO NOTHING;
INSERT INTO co_van(nguoi_dung_id) VALUES (2) ON CONFLICT DO NOTHING;
INSERT INTO nguoi_hoc(nguoi_dung_id,lop_hoc_id,co_van_id) VALUES (3,1,2),(4,1,2) ON CONFLICT DO NOTHING;
INSERT INTO ho_so_nang_luc(id,nguoi_hoc_id,diem_tong_hop,danh_gia) VALUES
 (1,3,4.80,'Cần được hỗ trợ cải thiện kết quả học tập'),
 (2,4,7.20,'Kết quả học tập ổn định')
ON CONFLICT DO NOTHING;
INSERT INTO ket_qua_hoc_tap(id,ho_so_id,mon_hoc,loai_danh_gia,diem,ngay_danh_gia) VALUES
 (1,1,'Lập trình hướng đối tượng','Kiểm tra giữa kỳ',4.50,'2026-10-01'),
 (2,1,'Cơ sở dữ liệu','Kiểm tra giữa kỳ',5.10,'2026-10-03'),
 (3,2,'Lập trình hướng đối tượng','Kiểm tra giữa kỳ',7.50,'2026-10-01'),
 (4,2,'Cơ sở dữ liệu','Kiểm tra giữa kỳ',6.90,'2026-10-03')
ON CONFLICT DO NOTHING;
INSERT INTO quy_tac_canh_bao(id,ten,loai_chi_so,toan_tu,nguong) VALUES
 (1,'Điểm tổng hợp dưới 5','DIEM_TONG_HOP','<',5.00)
ON CONFLICT DO NOTHING;
SELECT setval('nguoi_dung_id_seq',(SELECT GREATEST(COALESCE(MAX(id),1),1) FROM nguoi_dung));
SELECT setval('lop_hoc_id_seq',(SELECT GREATEST(COALESCE(MAX(id),1),1) FROM lop_hoc));
SELECT setval('ho_so_nang_luc_id_seq',(SELECT GREATEST(COALESCE(MAX(id),1),1) FROM ho_so_nang_luc));
SELECT setval('ket_qua_hoc_tap_id_seq',(SELECT GREATEST(COALESCE(MAX(id),1),1) FROM ket_qua_hoc_tap));
SELECT setval('quy_tac_canh_bao_id_seq',(SELECT GREATEST(COALESCE(MAX(id),1),1) FROM quy_tac_canh_bao));
