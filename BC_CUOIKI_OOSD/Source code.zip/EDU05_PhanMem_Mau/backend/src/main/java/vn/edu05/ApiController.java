package vn.edu05;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final JdbcTemplate db;
    private final PasswordEncoder passwords;

    public ApiController(JdbcTemplate db, PasswordEncoder passwords) {
        this.db = db;
        this.passwords = passwords;
    }

    private Map<String, Object> me(Principal principal) {
        return db.queryForMap("SELECT id, ten_dang_nhap, ho_ten, vai_tro FROM nguoi_dung WHERE ten_dang_nhap=?", principal.getName());
    }

    private long id(Map<String, Object> user) {
        return ((Number) user.get("id")).longValue();
    }

    private void role(Map<String, Object> user, String expected) {
        if (!expected.equals(user.get("vai_tro"))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Bạn không có quyền thực hiện thao tác này");
        }
    }

    private String required(Map<String, Object> body, String key) {
        String text = String.valueOf(body.getOrDefault(key, "")).trim();
        if (text.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Thiếu: " + key);
        return text;
    }

    private Map<String, Object> alert(long alertId) {
        var list = db.queryForList("SELECT * FROM canh_bao WHERE id=?", alertId);
        if (list.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Không tìm thấy cảnh báo");
        return list.get(0);
    }

    private void checkAdvisorForStudent(long advisorId, long studentId) {
        Integer count = db.queryForObject("SELECT COUNT(*) FROM nguoi_hoc WHERE nguoi_dung_id=? AND co_van_id=?", Integer.class, studentId, advisorId);
        if (count == null || count == 0) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Người học không thuộc phạm vi phụ trách");
    }

    private void checkAlertAccess(Map<String, Object> user, Map<String, Object> alert) {
        long studentId = ((Number) alert.get("nguoi_hoc_id")).longValue();
        if ("CO_VAN".equals(user.get("vai_tro"))) checkAdvisorForStudent(id(user), studentId);
        else if (!"HOC_VIEN".equals(user.get("vai_tro")) || id(user) != studentId) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Không thể xem cảnh báo này");
        }
    }

    @GetMapping("/me")
    public Map<String, Object> current(Principal principal) { return me(principal); }

    @GetMapping("/students")
    public List<Map<String, Object>> students(Principal principal) {
        var user = me(principal);
        role(user, "CO_VAN");
        return db.queryForList("""
            SELECT n.nguoi_dung_id AS id, u.ho_ten, l.ten_lop, h.diem_tong_hop,
                   (SELECT COUNT(*) FROM canh_bao c WHERE c.nguoi_hoc_id=n.nguoi_dung_id) AS so_canh_bao
            FROM nguoi_hoc n JOIN nguoi_dung u ON u.id=n.nguoi_dung_id
            JOIN lop_hoc l ON l.id=n.lop_hoc_id
            LEFT JOIN ho_so_nang_luc h ON h.nguoi_hoc_id=n.nguoi_dung_id
            WHERE n.co_van_id=? ORDER BY u.ho_ten
            """, id(user));
    }

    @GetMapping("/profiles/{studentId}")
    public Map<String, Object> profile(@PathVariable long studentId, Principal principal) {
        var user = me(principal);
        if ("CO_VAN".equals(user.get("vai_tro"))) checkAdvisorForStudent(id(user), studentId);
        else if (!"HOC_VIEN".equals(user.get("vai_tro")) || id(user) != studentId) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Không có quyền xem hồ sơ");
        }
        var detail = db.queryForList("""
            SELECT u.ho_ten, l.ten_lop, h.id AS ho_so_id, h.diem_tong_hop, h.danh_gia
            FROM nguoi_hoc n JOIN nguoi_dung u ON u.id=n.nguoi_dung_id
            JOIN lop_hoc l ON l.id=n.lop_hoc_id
            JOIN ho_so_nang_luc h ON h.nguoi_hoc_id=n.nguoi_dung_id
            WHERE n.nguoi_dung_id=?
            """, studentId);
        if (detail.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Chưa có hồ sơ");
        long profileId = ((Number) detail.get(0).get("ho_so_id")).longValue();
        return Map.of("hoSo", detail.get(0), "ketQua", db.queryForList(
            "SELECT mon_hoc, loai_danh_gia, diem, ngay_danh_gia FROM ket_qua_hoc_tap WHERE ho_so_id=? ORDER BY ngay_danh_gia DESC", profileId));
    }

    @GetMapping("/alerts")
    public List<Map<String, Object>> alerts(Principal principal) {
        var user = me(principal);
        if ("CO_VAN".equals(user.get("vai_tro"))) {
            return db.queryForList("""
                SELECT c.*, u.ho_ten AS nguoi_hoc, q.ten AS ten_quy_tac,
                    (SELECT p.noi_dung FROM phan_hoi p WHERE p.canh_bao_id=c.id ORDER BY p.id DESC LIMIT 1) AS phan_hoi_moi_nhat
                FROM canh_bao c JOIN nguoi_hoc n ON c.nguoi_hoc_id=n.nguoi_dung_id
                JOIN nguoi_dung u ON u.id=c.nguoi_hoc_id JOIN quy_tac_canh_bao q ON q.id=c.quy_tac_id
                WHERE n.co_van_id=? ORDER BY c.id DESC
                """, id(user));
        }
        role(user, "HOC_VIEN");
        // Nguoi hoc chi thay canh bao da duoc gui, khong thay NHAP va BI_TU_CHOI.
        return db.queryForList("""
            SELECT c.*, q.ten AS ten_quy_tac FROM canh_bao c
            JOIN quy_tac_canh_bao q ON q.id=c.quy_tac_id
            WHERE c.nguoi_hoc_id=? AND c.trang_thai IN ('DA_GUI','DA_PHAN_HOI','DA_XU_LY')
            ORDER BY c.id DESC
            """, id(user));
    }

    private boolean compare(BigDecimal value, String operator, BigDecimal threshold) {
        int cmp = value.compareTo(threshold);
        return switch (operator) {
            case "<" -> cmp < 0;
            case "<=" -> cmp <= 0;
            case ">" -> cmp > 0;
            case ">=" -> cmp >= 0;
            default -> false;
        };
    }

    // Sinh cảnh báo chỉ dựa trên ĐIỂM TỔNG HỢP, không có chuyên cần.
    private int generateInternal() {
        var rules = db.queryForList("SELECT * FROM quy_tac_canh_bao WHERE hoat_dong=true AND loai_chi_so='DIEM_TONG_HOP'");
        var students = db.queryForList("SELECT nguoi_hoc_id, diem_tong_hop FROM ho_so_nang_luc WHERE diem_tong_hop IS NOT NULL");
        int created = 0;
        for (var rule : rules) {
            for (var student : students) {
                long studentId = ((Number) student.get("nguoi_hoc_id")).longValue();
                long ruleId = ((Number) rule.get("id")).longValue();
                BigDecimal score = (BigDecimal) student.get("diem_tong_hop");
                BigDecimal threshold = (BigDecimal) rule.get("nguong");
                if (!compare(score, rule.get("toan_tu").toString(), threshold)) continue;
                Integer existing = db.queryForObject("""
                    SELECT COUNT(*) FROM canh_bao WHERE nguoi_hoc_id=? AND quy_tac_id=?
                    AND tao_luc::date=CURRENT_DATE
                    """, Integer.class, studentId, ruleId);
                if (existing != null && existing > 0) continue;
                String reason = "Điểm tổng hợp " + score + " " + rule.get("toan_tu") + " ngưỡng " + threshold;
                Long newId = db.queryForObject("""
                    INSERT INTO canh_bao(nguoi_hoc_id,quy_tac_id,gia_tri_thuc_te,nguong_ap_dung,ly_do)
                    VALUES (?,?,?,?,?) RETURNING id
                    """, Long.class, studentId, ruleId, score, threshold, reason);
                db.update("INSERT INTO lich_su_canh_bao(canh_bao_id,den_trang_thai,ghi_chu) VALUES (?,'NHAP','Sinh tự động theo quy tắc')", newId);
                created++;
            }
        }
        return created;
    }

    @PostMapping("/alerts/generate")
    @Transactional
    public Map<String, Object> generate(Principal principal) {
        role(me(principal), "CO_VAN");
        // Nut nay chi danh cho demo. Thuc te Scheduler chay theo lich.
        return Map.of("soCanhBaoMoi", generateInternal());
    }

    @Scheduled(cron="0 0 7 * * *")
    @Transactional
    public void generateScheduled() { generateInternal(); }

    private void history(long alertId, String from, String to, long actorId, String note) {
        db.update("INSERT INTO lich_su_canh_bao(canh_bao_id,tu_trang_thai,den_trang_thai,nguoi_thuc_hien_id,ghi_chu) VALUES (?,?,?,?,?)",
            alertId, from, to, actorId, note);
    }

    @PatchMapping("/alerts/{alertId}/review")
    @Transactional
    public Map<String, String> review(@PathVariable long alertId, @RequestBody Map<String, Object> body, Principal principal) {
        var user = me(principal); role(user, "CO_VAN");
        var record = alert(alertId);
        checkAdvisorForStudent(id(user), ((Number) record.get("nguoi_hoc_id")).longValue());
        if (!"NHAP".equals(record.get("trang_thai"))) throw new ResponseStatusException(HttpStatus.CONFLICT, "Cảnh báo không còn ở trạng thái Nháp");
        boolean approve = Boolean.TRUE.equals(body.get("duyet"));
        String reason = approve ? "" : required(body, "lyDo");
        String next = approve ? "DA_GUI" : "BI_TU_CHOI";
        int updated = db.update("""
            UPDATE canh_bao SET trang_thai=?, nguoi_duyet_id=?, ly_do_tu_choi=?,
            gui_luc=CASE WHEN ? THEN NOW() ELSE NULL END WHERE id=? AND trang_thai='NHAP'
            """, next, id(user), approve ? null : reason, approve, alertId);
        if (updated != 1) throw new ResponseStatusException(HttpStatus.CONFLICT, "Có người vừa xử lý cảnh báo");
        history(alertId, "NHAP", next, id(user), approve ? "Cố vấn duyệt" : reason);
        if (approve) db.update("INSERT INTO thong_bao(nguoi_nhan_id,canh_bao_id,noi_dung) VALUES (?,?,?)",
            record.get("nguoi_hoc_id"), alertId, "Bạn có cảnh báo học tập mới cần xem xét");
        return Map.of("trangThai", next);
    }

    @PostMapping("/alerts/{alertId}/feedback")
    @Transactional
    public Map<String, String> feedback(@PathVariable long alertId, @RequestBody Map<String, Object> body, Principal principal) {
        var user = me(principal); role(user, "HOC_VIEN");
        var record = alert(alertId); checkAlertAccess(user, record);
        if (!"DA_GUI".equals(record.get("trang_thai"))) throw new ResponseStatusException(HttpStatus.CONFLICT, "Chỉ phản hồi cảnh báo Đã gửi");
        String content = required(body, "noiDung");
        db.update("INSERT INTO phan_hoi(canh_bao_id,nguoi_hoc_id,noi_dung) VALUES (?,?,?)", alertId, id(user), content);
        int updated = db.update("UPDATE canh_bao SET trang_thai='DA_PHAN_HOI' WHERE id=? AND trang_thai='DA_GUI'", alertId);
        if (updated != 1) throw new ResponseStatusException(HttpStatus.CONFLICT, "Trạng thái cảnh báo đã thay đổi");
        history(alertId, "DA_GUI", "DA_PHAN_HOI", id(user), "Người học gửi phản hồi");
        return Map.of("trangThai", "DA_PHAN_HOI");
    }

    @PatchMapping("/alerts/{alertId}/resolve")
    @Transactional
    public Map<String, String> resolve(@PathVariable long alertId, @RequestBody Map<String,Object> body, Principal principal) {
        var user=me(principal); role(user,"CO_VAN");
        var record=alert(alertId); checkAdvisorForStudent(id(user), ((Number)record.get("nguoi_hoc_id")).longValue());
        if (!"DA_PHAN_HOI".equals(record.get("trang_thai"))) throw new ResponseStatusException(HttpStatus.CONFLICT,"Phải có phản hồi trước khi xử lý");
        String note=required(body,"ketLuan");
        int updated=db.update("UPDATE canh_bao SET trang_thai='DA_XU_LY' WHERE id=? AND trang_thai='DA_PHAN_HOI'",alertId);
        if(updated!=1) throw new ResponseStatusException(HttpStatus.CONFLICT,"Trạng thái đã thay đổi");
        history(alertId,"DA_PHAN_HOI","DA_XU_LY",id(user),note);
        return Map.of("trangThai","DA_XU_LY");
    }

    @PostMapping("/alerts/{alertId}/plans")
    @Transactional
    public Map<String, Object> createPlan(@PathVariable long alertId, @RequestBody Map<String,Object> body, Principal principal) {
        var user=me(principal); role(user,"CO_VAN");
        var record=alert(alertId); checkAdvisorForStudent(id(user),((Number)record.get("nguoi_hoc_id")).longValue());
        if ("NHAP".equals(record.get("trang_thai")) || "BI_TU_CHOI".equals(record.get("trang_thai")))
            throw new ResponseStatusException(HttpStatus.CONFLICT,"Cảnh báo chưa được duyệt");
        Integer has=db.queryForObject("SELECT COUNT(*) FROM ke_hoach_can_thiep WHERE canh_bao_id=?",Integer.class,alertId);
        if(has!=null && has>0) throw new ResponseStatusException(HttpStatus.CONFLICT,"Cảnh báo đã có kế hoạch");
        LocalDate start=LocalDate.parse(required(body,"batDau"));
        LocalDate deadline=LocalDate.parse(required(body,"hanHoanThanh"));
        if(deadline.isBefore(start)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Hạn hoàn thành trước ngày bắt đầu");
        Long planId=db.queryForObject("""
            INSERT INTO ke_hoach_can_thiep(canh_bao_id,co_van_id,muc_tieu,bien_phap,bat_dau,han_hoan_thanh)
            VALUES (?,?,?,?,?,?) RETURNING id
            """,Long.class,alertId,id(user),required(body,"mucTieu"),required(body,"bienPhap"),start,deadline);
        return Map.of("id",planId);
    }

    @GetMapping("/plans")
    public List<Map<String,Object>> plans(Principal principal) {
        var user=me(principal); role(user,"CO_VAN");
        return db.queryForList("""
            SELECT p.*, u.ho_ten AS nguoi_hoc FROM ke_hoach_can_thiep p
            JOIN canh_bao c ON c.id=p.canh_bao_id JOIN nguoi_dung u ON u.id=c.nguoi_hoc_id
            WHERE p.co_van_id=? ORDER BY p.id DESC
            """,id(user));
    }

    @GetMapping("/admin/users")
    public List<Map<String,Object>> users(Principal principal) {
        role(me(principal),"QUAN_TRI");
        return db.queryForList("SELECT id,ten_dang_nhap,ho_ten,vai_tro,trang_thai FROM nguoi_dung ORDER BY id");
    }

    @PostMapping("/admin/users")
    @Transactional
    public Map<String,Object> addUser(@RequestBody Map<String,Object> body,Principal principal) {
        role(me(principal),"QUAN_TRI");
        String username=required(body,"tenDangNhap");
        String fullName=required(body,"hoTen");
        String userRole=required(body,"vaiTro");
        String pass=required(body,"matKhau");
        if(pass.length()<8) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Mật khẩu phải có ít nhất 8 ký tự");
        if(!List.of("HOC_VIEN","CO_VAN","QUAN_TRI").contains(userRole))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Vai trò không hợp lệ");
        Long newId=db.queryForObject("""
            INSERT INTO nguoi_dung(ten_dang_nhap,ho_ten,vai_tro,mat_khau_hash)
            VALUES (?,?,?,?) RETURNING id
            """,Long.class,username,fullName,userRole,passwords.encode(pass));
        if("CO_VAN".equals(userRole)) db.update("INSERT INTO co_van(nguoi_dung_id) VALUES (?)",newId);
        if("HOC_VIEN".equals(userRole)) {
            // Demo: gán lớp và cố vấn mẫu để tạo hồ sơ trống; triển khai thật có màn hình chọn.
            db.update("INSERT INTO nguoi_hoc(nguoi_dung_id,lop_hoc_id,co_van_id) VALUES (?,1,2)",newId);
            db.update("INSERT INTO ho_so_nang_luc(nguoi_hoc_id,danh_gia) VALUES (?,'Chưa có kết quả đánh giá')",newId);
        }
        return Map.of("id",newId);
    }

    @PatchMapping("/admin/users/{userId}/status")
    public Map<String,String> userStatus(@PathVariable long userId,@RequestBody Map<String,Object> body,Principal principal) {
        var current=me(principal); role(current,"QUAN_TRI");
        if(id(current)==userId) throw new ResponseStatusException(HttpStatus.CONFLICT,"Không tự khóa tài khoản đang dùng");
        String status=required(body,"trangThai");
        if(!List.of("KHOA","HOAT_DONG").contains(status)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Trạng thái không hợp lệ");
        db.update("UPDATE nguoi_dung SET trang_thai=? WHERE id=?",status,userId);
        return Map.of("trangThai",status);
    }

    @GetMapping("/admin/rules")
    public List<Map<String,Object>> rules(Principal principal) {
        role(me(principal),"QUAN_TRI");
        return db.queryForList("SELECT * FROM quy_tac_canh_bao ORDER BY id");
    }

    @PostMapping("/admin/rules")
    public Map<String,Object> addRule(@RequestBody Map<String,Object> body,Principal principal) {
        role(me(principal),"QUAN_TRI");
        String operator=required(body,"toanTu");
        if(!List.of("<","<=",">",">=").contains(operator)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Toán tử không hợp lệ");
        BigDecimal threshold=new BigDecimal(required(body,"nguong"));
        if(threshold.compareTo(BigDecimal.ZERO)<0 || threshold.compareTo(BigDecimal.TEN)>0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Ngưỡng phải từ 0 đến 10");
        Long newId=db.queryForObject("""
            INSERT INTO quy_tac_canh_bao(ten,loai_chi_so,toan_tu,nguong)
            VALUES (?,'DIEM_TONG_HOP',?,?) RETURNING id
            """,Long.class,required(body,"ten"),operator,threshold);
        return Map.of("id",newId);
    }

    @PutMapping("/password")
    public Map<String,String> password(@RequestBody Map<String,Object> body,Principal principal) {
        String oldPass=required(body,"matKhauCu");
        String newPass=required(body,"matKhauMoi");
        if(newPass.length()<8) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Mật khẩu mới tối thiểu 8 ký tự");
        var user=me(principal);
        String stored=db.queryForObject("SELECT mat_khau_hash FROM nguoi_dung WHERE id=?",String.class,id(user));
        if(!passwords.matches(oldPass,stored)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Mật khẩu hiện tại không đúng");
        db.update("UPDATE nguoi_dung SET mat_khau_hash=? WHERE id=?",passwords.encode(newPass),id(user));
        return Map.of("message","Đổi mật khẩu thành công; hãy đăng nhập lại");
    }

    @GetMapping("/health")
    public Map<String,String> health() { return Map.of("status","OK"); }
}
