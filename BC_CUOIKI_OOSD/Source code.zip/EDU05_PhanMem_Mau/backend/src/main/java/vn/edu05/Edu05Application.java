package vn.edu05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class Edu05Application {
    public static void main(String[] args) {
        SpringApplication.run(Edu05Application.class, args);
    }
}
