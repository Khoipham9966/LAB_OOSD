# EDU-05 — HƯỚNG DẪN CHẠY BẢN PHẦN MỀM MẪU (WINDOWS)

**Mục tiêu:** chạy bản demo có giao diện React, API Spring Boot và cơ sở dữ liệu PostgreSQL thật. Mã nguồn được giữ đơn giản, không dùng Next.js, Redux, Tailwind, Docker ở bước này.

> **Phạm vi:** đây là BẢN MẪU CHO DEMO LOCAL, không phải ứng dụng đã được kiểm thử triển khai chính thức. Cơ chế HTTP Basic, mật khẩu mẫu và cách lưu phiên đăng nhập được dùng chỉ để giảm độ phức tạp cho buổi thực hành. Không đưa ứng dụng mẫu lên Internet. Khi triển khai thật cần HTTPS, xác thực phiên/token phù hợp, bảo vệ CSRF và quản lý cấu hình bí mật.

## A. Những gì cần cài

1. **JDK 25**: https://adoptium.net/temurin/releases/?version=25
2. **Visual Studio Code**: https://code.visualstudio.com/
3. **Apache Maven 3.9+**: https://maven.apache.org/download.cgi (hoặc Maven đã đi kèm môi trường IDE phù hợp).
4. **Node.js LTS**: https://nodejs.org/ — kiểm tra `node -v`, `npm -v`.
5. **PostgreSQL + pgAdmin 4**: https://www.postgresql.org/download/windows/ — trình cài Windows thường kèm pgAdmin.
6. **Postman** (không bắt buộc): https://www.postman.com/downloads/

Trong VS Code có thể cài extension **Extension Pack for Java** và **Spring Boot Extension Pack**. Có thể dùng VS Code để sửa cả frontend lẫn backend.

## B. Kiểm tra sau khi cài đặt

Mở **PowerShell** hoặc Terminal trong VS Code và chạy:

```powershell
java -version
mvn -version
node -v
npm -v
```

`java -version` phải là **25** nếu dùng đúng cấu hình của đề tài. Nếu `mvn` không được nhận diện, hãy cài Maven và thêm thư mục `bin` của Maven vào Windows PATH.

## C. Tạo database bằng pgAdmin 4

1. Mở **pgAdmin 4**, kết nối server PostgreSQL local. Nếu yêu cầu mật khẩu, nhập mật khẩu `postgres` mà bạn đã đặt khi cài.
2. Mở `Servers > PostgreSQL > Databases`.
3. Chuột phải `Databases > Create > Database...`, đặt tên **edu05** rồi lưu.
4. Chọn database `edu05`, nhấn **Tools > Query Tool**.
5. Mở `database/01_schema.sql` trong Query Tool; bấm **Execute (F5)**.
6. Tiếp tục mở `database/02_du_lieu_mau.sql`; bấm **Execute (F5)**.
7. Refresh `Schemas > public > Tables` để thấy **12 bảng**.

Bạn có thể mở bảng `nguoi_dung`, `canh_bao`, `ho_so_nang_luc`, ... bằng chuột phải > **View/Edit Data > All Rows**. Chọn ô cần thay đổi và bấm **Save Data** để lưu thật vào PostgreSQL.

**Lưu ý:** có thể dùng mật khẩu PostgreSQL tùy bạn đặt, không nhất thiết phải là `postgres`. Không sửa dữ liệu thật của người khác để demo.

## D. Chạy backend Spring Boot (cửa sổ Terminal 1)

Trong Windows PowerShell:

```powershell
cd .\EDU05_PhanMem_Mau\backend
$env:DB_USER="postgres"
$env:DB_PASSWORD="MAT_KHAU_POSTGRES_CUA_BAN"
mvn spring-boot:run
```

Nếu bạn đã giải nén và mở thư mục `EDU05_PhanMem_Mau` trong VS Code, chạy:

```powershell
cd backend
$env:DB_PASSWORD="MAT_KHAU_POSTGRES_CUA_BAN"
mvn spring-boot:run
```

Khi Terminal báo có dòng tương tự `Tomcat started on port 8080`, backend đã lên. Kiểm tra:

```powershell
curl.exe -u covan:Demo@123 http://localhost:8080/api/me
```

Kết quả mong đợi là JSON có tên tài khoản và vai trò `CO_VAN`. **Không đóng Terminal 1** khi đang demo.

## E. Chạy giao diện React (cửa sổ Terminal 2)

Mở **Terminal mới** (khác với Terminal backend):

```powershell
cd .\EDU05_PhanMem_Mau\frontend
npm install
npm run dev
```

Nếu VS Code đã mở thư mục gốc `EDU05_PhanMem_Mau`:

```powershell
cd frontend
npm install
npm run dev
```

Mở trình duyệt đến **http://localhost:5173**. Vite sẽ tự cập nhật phần giao diện sau khi bạn sửa `App.jsx` hoặc `style.css` rồi nhấn Ctrl+S.

## F. Tài khoản demo

| Vai trò | Tài khoản | Mật khẩu |
|---|---|---|
| Quản trị viên | `admin` | `Demo@123` |
| Cố vấn | `covan` | `Demo@123` |
| Người học (có điểm thấp) | `sinhvien1` | `Demo@123` |
| Người học (điểm bình thường) | `sinhvien2` | `Demo@123` |

Tất cả là **dữ liệu giả lập** và mật khẩu trong database được lưu dưới dạng BCrypt hash. Trong môi trường thật phải bỏ hoặc thay tài khoản mẫu.

## G. Luồng chạy thử đầy đủ

1. Đăng nhập **covan / Demo@123**. Kiểm tra danh sách người học; `Trần An` có `diem_tong_hop=4.80`, `Lê Bình` có `7.20`.
2. Mở tab **Cảnh báo**, chọn **Chạy kiểm tra cảnh báo (demo)**. Hệ thống đối chiếu quy tắc `điểm tổng hợp < 5`, tạo cảnh báo **Nháp** cho Trần An.
3. Cố vấn chọn **Duyệt**. Trạng thái thành **Đã gửi**. Có thể thử nút **Từ chối** với một cảnh báo Nháp khác để thấy nhánh `Bị từ chối` được lưu, không bị xóa.
4. Đăng xuất, đăng nhập **sinhvien1 / Demo@123**. Mở **Cảnh báo của tôi**, nhập lời phản hồi và nhấn **Gửi phản hồi**. Trạng thái thành **Đã phản hồi**.
5. Đăng nhập lại **covan**. Mở **Cảnh báo**, bấm **Đánh dấu Đã xử lý** và nhập kết luận. Trạng thái thành **Đã xử lý**.
6. Vẫn dùng cố vấn: chọn **Lập kế hoạch** tại cảnh báo đã gửi/xử lý; điền mục tiêu, biện pháp, thời hạn và lưu kế hoạch.
7. Đăng nhập **admin**. Xem **Quản lý tài khoản**, **Quy tắc cảnh báo**. Có thể tạo quy tắc mới để thử ngưỡng khác.

**Lưu ý về thời gian:** API chống tạo bản ghi cảnh báo trùng cho cùng người học/quy tắc trong cùng ngày. Bấm tạo lại ngay có thể trả `0 cảnh báo mới`: đó là hành vi có chủ ý.

## H. Chứng minh SQL có thể chỉnh trực tiếp

### Cách dùng giao diện (dễ nhất)

Trong pgAdmin: `Databases > edu05 > Schemas > public > Tables > ho_so_nang_luc` > **View/Edit Data > All Rows**.

- Trường `diem_tong_hop` của `nguoi_hoc_id=4` ban đầu là `7.20`.
- Sửa thành `4.40` rồi nhấn **Save Data**.
- Vào giao diện cố vấn, bấm **Chạy kiểm tra cảnh báo (demo)**.
- Sẽ có một cảnh báo Nháp mới cho Lê Bình theo ngưỡng `< 5`. (Giả sử chưa sinh cảnh báo đó trước trong cùng ngày.)

### Cách chạy SQL (nên biết khi thầy hỏi)

```sql
SELECT * FROM ho_so_nang_luc ORDER BY id;
UPDATE ho_so_nang_luc SET diem_tong_hop = 4.40, cap_nhat_luc = NOW()
WHERE nguoi_hoc_id = 4;
SELECT id, nguoi_hoc_id, gia_tri_thuc_te, nguong_ap_dung, trang_thai
FROM canh_bao ORDER BY id DESC;
```

Lưu ý: đây là thao tác sửa chỉ số tổng hợp **để minh họa dữ liệu thay đổi trong demo**. Sau khi xây dựng chức năng nhập điểm thật, cần cập nhật điểm tổng hợp tự động từ `ket_qua_hoc_tap` để hai nơi nhất quán.

## I. Thầy yêu cầu sửa giao diện ngay trên máy

| Thầy yêu cầu | File cần mở | Cách sửa |
|---|---|---|
| Đổi tiêu đề “HỆ THỐNG CỐ VẤN HỌC TẬP” | `frontend/src/App.jsx` | Ctrl+F tìm câu đó và sửa văn bản |
| Đổi màu xanh thành màu khác | `frontend/src/style.css` | Sửa `--blue: #326fa8` |
| Đổi tên cột “Điểm tổng hợp” | `frontend/src/App.jsx` | Ctrl+F `Điểm tổng hợp`, sửa text trong `<th>` |
| Thêm cột mã sinh viên | `frontend/src/App.jsx` | Thêm một cặp `<th>...</th>` và `<td>...</td>` trong bảng |
| Thay điểm của sinh viên | pgAdmin 4 | Sửa ô dữ liệu ở `ho_so_nang_luc` hoặc dùng `UPDATE` |
| Thay ngưỡng cảnh báo | Trang admin hoặc pgAdmin | Sửa `quy_tac_canh_bao.nguong` |
| Đổi cách sinh cảnh báo | `backend/src/main/java/vn/edu05/ApiController.java` | Tìm hàm `generateInternal()` |
| Thay luật chuyển trạng thái | Cũng trong `ApiController.java` | Xem `review()`, `feedback()`, `resolve()` |

Sửa **frontend** thì Vite thường tự tải lại. Sửa **backend Java** thì cần **dừng backend Ctrl+C và chạy lại `mvn spring-boot:run`** (nếu chưa thiết lập hot reload).

## J. Những giới hạn cần nói thật với thầy

- Bản mẫu được xây dựng để chạy **local** và kiểm tra các luồng chính, không phải đã hoàn thành đo hiệu năng, audit bảo mật hay triển khai sản xuất.
- Một số chức năng mở rộng như tải tệp minh chứng thật, cập nhật trạng thái kế hoạch và thống kê nâng cao chưa được hiện thực trong mẫu này.
- Java code được cố ý viết gọn bằng `JdbcTemplate` và SQL trực tiếp; vẫn cần bổ sung test tự động, phân tầng Service/Repository rõ ràng hơn nếu mục tiêu là hệ thống sản xuất.
- Chưa có Docker và GitHub Actions trong bộ mẫu. Chỉ ghi hai công cụ này là **định hướng** trong báo cáo cho đến khi chúng được cấu hình và kiểm chứng.
- Cơ chế Basic Auth + `sessionStorage` chỉ phục vụ demo trong `localhost`; phải thay đổi trước khi đưa lên Internet.
- Không sử dụng chuyên cần hay số buổi vắng làm tiêu chí đánh giá.

## K. Cách xử lý sự cố phổ biến

| Hiện tượng | Nguyên nhân thường gặp | Cách xử lý |
|---|---|---|
| `java -version` khác 25 | PATH / JAVA_HOME chưa đúng | Đặt JDK 25 làm mặc định, khởi động lại Terminal |
| `mvn` không được nhận diện | Chưa cài Maven/PATH | Cài Maven và thêm `bin` vào PATH |
| Backend báo `Connection refused` | PostgreSQL chưa chạy | Mở Services, chạy PostgreSQL, kiểm tra port `5432` |
| Backend báo `password authentication failed` | Sai mật khẩu PostgreSQL | Sửa `$env:DB_PASSWORD` |
| SQL báo bảng chưa tồn tại | Chưa chạy `01_schema.sql` | Chạy schema rồi dữ liệu mẫu trong đúng database `edu05` |
| Web báo `Failed to fetch` / proxy lỗi | Backend 8080 chưa chạy | Chạy backend trước, xem Terminal 1 |
| Đăng nhập luôn sai | Dữ liệu mẫu chưa chạy, tài khoản bị khóa | Kiểm tra bảng `nguoi_dung` và chạy lại `02_du_lieu_mau.sql` nếu DB trống |
| Vite nói `node version unsupported` | Node quá cũ | Nâng cấp Node LTS; Vite cần 20.19+ hoặc 22.12+ |
| Bấm sinh cảnh báo ra 0 | Không thỏa ngưỡng hoặc đã sinh trong ngày | Kiểm tra dữ liệu `ho_so_nang_luc`, `quy_tac_canh_bao`, `canh_bao` |

## L. Các file bạn cần hiểu nhất

- `frontend/src/App.jsx`: toàn bộ chữ, bảng, nút và các màn hình.
- `frontend/src/style.css`: màu sắc, kích thước, vị trí giao diện.
- `frontend/src/api.js`: cách gọi API từ React.
- `backend/src/main/java/vn/edu05/ApiController.java`: các endpoint và xử lý nghiệp vụ.
- `backend/src/main/resources/application.properties`: kết nối PostgreSQL.
- `database/01_schema.sql`: tạo bảng.
- `database/02_du_lieu_mau.sql`: tài khoản và điểm mẫu.
